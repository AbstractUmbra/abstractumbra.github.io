import enum
import functools
import itertools
import reprlib
import sys
import threading
from array import array
from collections.abc import (
    Callable,
    ItemsView,
    Iterable,
    Iterator,
    KeysView,
    Mapping,
    ValuesView,
)
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Generic,
    NoReturn,
    TypeVar,
    cast,
    final,
    overload,
)

from ._abc import MDArg, MultiMapping, MutableMultiMapping, SupportsKeys

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

MAXSIZE = sys.maxsize

# Entry hashes are folded non-negative (& MAXSIZE) so HASH_MARK, the
# hash range's high bit, can mark a hash as temporarily invalid: OR it in,
# AND it out with MAXSIZE. A real folded hash never has that bit set.
HASH_MARK = MAXSIZE + 1
# Same as HT_LOG_RESUME_SLOTS_MINSIZE and HT_RESUME_SLOTS_MIN_STEPS in htkeys.h
_LOG_RESUME_SLOTS_MINSIZE = 10
_RESUME_SLOTS_MIN_STEPS = 32


@final
class istr(str):
    """Case insensitive str."""

    def __init_subclass__(cls, **kwargs: object) -> None:
        raise TypeError(f"type '{istr.__module__}.istr' is not an acceptable base type")

    # Implementation note:
    # The class doesn't use __slots__ because slot-based memory model
    # is ~20% slower than classic __dict__-based one.
    # See also: https://github.com/aio-libs/multidict/pull/1386

    __is_istr__ = True
    __istr_identity__: str | None = None


_V = TypeVar("_V")
_T = TypeVar("_T")

_SENTINEL = enum.Enum("_SENTINEL", "sentinel")
sentinel = _SENTINEL.sentinel

_version = itertools.count(1)

_FREE_THREADED = hasattr(sys, "_is_gil_enabled") and not sys._is_gil_enabled()

_VERSION_LOCK = threading.Lock()


def _other_lock(arg: object) -> "threading.RLock | None":
    """Return the RLock backing `arg`, if it's a multidict, one of our
    own views over one, or an iterator over one, that we don't already
    own."""
    if isinstance(arg, MultiDictProxy):
        return arg._md._lock
    if isinstance(arg, MultiDict):
        return arg._lock
    if isinstance(arg, (_ItemsView, _KeysView, _ValuesView)):
        return arg._md._lock
    if isinstance(arg, _Iter):
        return arg._lock
    return None


def _iter_lock(md: "MultiDict[Any]") -> "threading.RLock | None":
    """Return the lock a view iterator over `md` should take per step."""
    return md._lock if _FREE_THREADED else None


class _PairLock:
    """Acquire one or two RLocks in a fixed, deadlock-safe order."""

    __slots__ = ("_a", "_b")

    def __init__(self, a: "threading.RLock", b: "threading.RLock | None") -> None:
        if b is None or b is a:
            self._a: threading.RLock | None = a
            self._b: threading.RLock | None = None
        elif id(a) < id(b):
            self._a, self._b = a, b
        else:
            self._a, self._b = b, a

    def __enter__(self) -> None:
        assert self._a is not None
        self._a.acquire()
        if self._b is not None:
            self._b.acquire()

    def __exit__(self, *exc: object) -> None:
        assert self._a is not None
        if self._b is not None:
            self._b.release()
        self._a.release()


_F = TypeVar("_F", bound=Callable[..., Any])


def _locked_always(fn: _F) -> _F:
    """Wrap `fn` to hold `self._lock` for the call, on every build.

    update()/extend()/merge()/clear()/popitem() have their own race that,
    unlike the rest of this module's locking, is not specific to
    free-threading: pure-Python bytecode is not atomic even under the GIL
    (the GIL can be released between any two bytecodes), so enough
    concurrent contention lets two calls interleave mid hash-table insert
    or deletion and corrupt the shared index table. `_locked`/`_locked_pair`
    skip locking on a GIL-enabled build because the race they guard against
    is free-threading-only; this variant cannot.
    """

    @functools.wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
        with self._lock:
            return fn(self, *args, **kwargs)

    return cast(_F, wrapper)


def _locked_pair_always(fn: _F) -> _F:
    """Like `_locked_always`, but also pairs in the first argument's lock,
    for the same reason `_locked_pair` does."""

    @functools.wraps(fn)
    def wrapper(self: Any, arg: Any = None, *args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
        with _PairLock(self._lock, _other_lock(arg)):
            return fn(self, arg, *args, **kwargs)

    return cast(_F, wrapper)


def _locked(fn: _F) -> _F:
    """Wrap `fn` to hold `self._lock` for the call, but only when it
    guards against a free-threading-only race; see `_locked_always` for
    the unconditional version a few methods need."""
    if not _FREE_THREADED:
        return fn
    return _locked_always(fn)


def _locked_md(fn: _F) -> _F:
    """Like `_locked`, but for view objects: holds `self._md._lock`."""
    if not _FREE_THREADED:
        return fn

    @functools.wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
        with self._md._lock:
            return fn(self, *args, **kwargs)

    return cast(_F, wrapper)


def _locked_pair(fn: _F) -> _F:
    """Wrap `fn` to hold `self._lock` and its first argument's lock, but
    only when it guards against a free-threading-only race; see
    `_locked_pair_always`."""
    if not _FREE_THREADED:
        return fn
    return _locked_pair_always(fn)


def _locked_md_pair(fn: _F) -> _F:
    """Like `_locked_md`, but also pairs in its first argument's lock."""
    if not _FREE_THREADED:
        return fn

    @functools.wraps(fn)
    def wrapper(self: Any, other: Any = None, *args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
        with _PairLock(self._md._lock, _other_lock(other)):
            return fn(self, other, *args, **kwargs)

    return cast(_F, wrapper)


class _Iter(Generic[_T]):
    __slots__ = ("_size", "_iter", "_lock")

    def __init__(
        self,
        size: int,
        iterator: Iterator[_T],
        lock: "threading.RLock | None" = None,
    ):
        self._size = size
        self._iter = iterator
        self._lock = lock

    def __iter__(self) -> Self:
        return self

    @_locked
    def __next__(self) -> _T:
        return next(self._iter)

    def __length_hint__(self) -> int:
        return self._size


class _ViewBase(Generic[_V]):
    def __init__(
        self,
        md: "MultiDict[_V]",
    ):
        self._md = md

    def __len__(self) -> int:
        return len(self._md)


class _ItemsView(_ViewBase[_V], ItemsView[str, _V]):
    @_locked_md
    def __contains__(self, item: object) -> bool:
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            return False
        key, value = item
        try:
            identity = self._md._identity(key)
        except TypeError:
            return False
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._md._keys.iter_hash(hash_):
            if e.identity == identity and value == e.value:
                return True
        return False

    def __iter__(self) -> _Iter[tuple[str, _V]]:
        return _Iter(len(self), self._iter(self._md._version), _iter_lock(self._md))

    def __reversed__(self) -> _Iter[tuple[str, _V]]:
        return _Iter(
            len(self),
            self._iter(self._md._version, reverse=True),
            _iter_lock(self._md),
        )

    def _iter(self, version: int, reverse: bool = False) -> Iterator[tuple[str, _V]]:
        entries = self._md._keys.iter_entries(reverse)
        while True:
            if version != self._md._version:
                raise RuntimeError("Dictionary changed during iteration")
            try:
                e = next(entries)
            except StopIteration:
                return
            yield self._md._key(e.key), e.value

    @reprlib.recursive_repr()
    @_locked_md
    def __repr__(self) -> str:
        lst = []
        for e in self._md._keys.iter_entries():
            lst.append(f"{e.key!r}: {e.value!r}")
        body = ", ".join(lst)
        return f"<{self.__class__.__name__}({body})>"

    def _parse_item(self, arg: tuple[str, _V] | _T) -> tuple[int, str, str, _V] | None:
        if not isinstance(arg, tuple):
            return None
        if len(arg) != 2:
            return None
        try:
            identity = self._md._identity(arg[0])
            return (hash(identity) & MAXSIZE, identity, arg[0], arg[1])
        except TypeError:
            return None

    def _tmp_set(self, it: Iterable[_T]) -> set[tuple[str, _V]]:
        tmp = set()
        for arg in it:
            item = self._parse_item(arg)
            if item is None:
                continue
            else:
                tmp.add((item[1], item[3]))
        return tmp

    @_locked_md_pair
    def __and__(self, other: Iterable[Any]) -> set[tuple[str, _V]]:  # type: ignore[misc]
        ret = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for arg in it:
            item = self._parse_item(arg)
            if item is None:
                continue
            hash_, identity, key, value = item
            matches = []
            last = -1
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if idx > last and e.identity == identity:
                    matches.append((e.key, e.value))
                    last = idx
            for e_key, e_value in matches:
                if e_value == value:
                    ret.add((e_key, e_value))
        return ret

    @_locked_md_pair
    def __rand__(self, other: Iterable[_T]) -> set[_T]:
        ret = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for arg in it:
            item = self._parse_item(arg)
            if item is None:
                continue
            hash_, identity, key, value = item
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity and e.value == value:
                    ret.add(arg)
                    break
        return ret

    @_locked_md_pair
    def __or__(self, other: Iterable[_T]) -> set[tuple[str, _V] | _T]:
        ret: set[tuple[str, _V] | _T] = set(self)
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for arg in it:
            item: tuple[int, str, str, _V] | None = self._parse_item(arg)
            if item is None:
                ret.add(arg)
                continue
            hash_, identity, key, value = item
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity and e.value == value:  # pragma: no branch
                    break
            else:
                ret.add(arg)
        return ret

    @_locked_md_pair
    def __ror__(self, other: Iterable[_T]) -> set[tuple[str, _V] | _T]:
        try:
            ret: set[tuple[str, _V] | _T] = set(other)
        except TypeError:
            return NotImplemented
        tmp = self._tmp_set(ret)

        for e in self._md._keys.iter_entries():
            if (e.identity, e.value) not in tmp:
                ret.add((e.key, e.value))
        return ret

    @_locked_md_pair
    def __sub__(self, other: Iterable[_T]) -> set[tuple[str, _V] | _T]:
        ret: set[tuple[str, _V] | _T] = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        tmp = self._tmp_set(it)

        for e in self._md._keys.iter_entries():
            if (e.identity, e.value) not in tmp:
                ret.add((e.key, e.value))

        return ret

    @_locked_md_pair
    def __rsub__(self, other: Iterable[_T]) -> set[_T]:
        ret: set[_T] = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for arg in it:
            item = self._parse_item(arg)
            if item is None:
                ret.add(arg)
                continue

            hash_, identity, key, value = item
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity and e.value == value:  # pragma: no branch
                    break
            else:
                ret.add(arg)
        return ret

    @_locked_md_pair
    def __xor__(self, other: Iterable[_T]) -> set[tuple[str, _V] | _T]:
        try:
            rgt = set(other)
        except TypeError:
            return NotImplemented
        ret: set[tuple[str, _V] | _T] = self - rgt
        ret |= rgt - self
        return ret

    __rxor__ = __xor__

    @_locked_md_pair
    def isdisjoint(self, other: Iterable[tuple[str, _V]]) -> bool:
        for arg in other:
            item = self._parse_item(arg)
            if item is None:
                continue

            hash_, identity, key, value = item
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity and e.value == value:  # pragma: no branch
                    return False
        return True


class _ValuesView(_ViewBase[_V], ValuesView[_V]):
    @_locked_md
    def __contains__(self, value: object) -> bool:
        for e in self._md._keys.iter_entries():
            if e.value == value:
                return True
        return False

    def __iter__(self) -> _Iter[_V]:
        return _Iter(len(self), self._iter(self._md._version), _iter_lock(self._md))

    def __reversed__(self) -> _Iter[_V]:
        return _Iter(
            len(self),
            self._iter(self._md._version, reverse=True),
            _iter_lock(self._md),
        )

    def _iter(self, version: int, reverse: bool = False) -> Iterator[_V]:
        entries = self._md._keys.iter_entries(reverse)
        while True:
            if version != self._md._version:
                raise RuntimeError("Dictionary changed during iteration")
            try:
                e = next(entries)
            except StopIteration:
                return
            yield e.value

    @reprlib.recursive_repr()
    @_locked_md
    def __repr__(self) -> str:
        lst = []
        for e in self._md._keys.iter_entries():
            lst.append(repr(e.value))
        body = ", ".join(lst)
        return f"<{self.__class__.__name__}({body})>"


class _KeysView(_ViewBase[_V], KeysView[str]):
    @_locked_md
    def __len__(self) -> int:
        return sum(1 for _ in self._md._keys.iter_first_entries())

    @_locked_md
    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        identity = self._md._identity(key)
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._md._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                return True
        return False

    def __iter__(self) -> _Iter[str]:
        return _Iter(len(self._md), self._iter(self._md._version), _iter_lock(self._md))

    def __reversed__(self) -> _Iter[str]:
        return _Iter(
            len(self._md),
            self._iter(self._md._version, reverse=True),
            _iter_lock(self._md),
        )

    def _iter(self, version: int, reverse: bool = False) -> Iterator[str]:
        keys = self._md._keys
        if keys.maybe_dups:
            entries = keys.iter_first_entries(reverse)
        else:
            entries = keys.iter_entries(reverse)
        while True:
            if version != self._md._version:
                raise RuntimeError("Dictionary changed during iteration")
            try:
                e = next(entries)
            except StopIteration:
                return
            yield self._md._key(e.key)

    @reprlib.recursive_repr()
    @_locked_md
    def __repr__(self) -> str:
        lst = []
        for e in self._md._keys.iter_first_entries():
            lst.append(f"{e.key!r}")
        body = ", ".join(lst)
        return f"<{self.__class__.__name__}({body})>"

    @_locked_md_pair
    def __and__(self, other: Iterable[object]) -> set[str]:
        ret = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for key in it:
            if not isinstance(key, str):
                continue
            identity = self._md._identity(key)
            hash_ = hash(identity) & MAXSIZE
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity:  # pragma: no branch
                    ret.add(e.key)
                    break
        return ret

    @_locked_md_pair
    def __rand__(self, other: Iterable[_T]) -> set[_T]:
        ret = set()
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for key in it:
            if not isinstance(key, str):
                continue
            if key in self._md:
                ret.add(key)
        return cast(set[_T], ret)

    @_locked_md_pair
    def __or__(self, other: Iterable[_T]) -> set[str | _T]:
        ret: set[str | _T] = set(self)
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for key in it:
            if not isinstance(key, str):
                ret.add(key)
                continue
            if key not in self._md:
                ret.add(key)
        return ret

    @_locked_md_pair
    def __ror__(self, other: Iterable[_T]) -> set[str | _T]:
        try:
            ret: set[str | _T] = set(other)
        except TypeError:
            return NotImplemented

        tmp = set()
        for key in ret:
            if not isinstance(key, str):
                continue
            identity = self._md._identity(key)
            tmp.add(identity)

        for e in self._md._keys.iter_first_entries():
            if e.identity not in tmp:
                ret.add(e.key)
        return ret

    @_locked_md_pair
    def __sub__(self, other: Iterable[object]) -> set[str]:
        ret = set(self)
        try:
            it = iter(other)
        except TypeError:
            return NotImplemented
        for key in it:
            if not isinstance(key, str):
                continue
            identity = self._md._identity(key)
            hash_ = hash(identity) & MAXSIZE
            for slot, idx, e in self._md._keys.iter_hash(hash_):
                if e.identity == identity:  # pragma: no branch
                    ret.discard(e.key)
                    break
        return ret

    @_locked_md_pair
    def __rsub__(self, other: Iterable[_T]) -> set[_T]:
        try:
            ret: set[_T] = set(other)
        except TypeError:
            return NotImplemented
        for key in other:
            if not isinstance(key, str):
                continue
            if key in self._md:
                ret.discard(key)
        return ret

    @_locked_md_pair
    def __xor__(self, other: Iterable[_T]) -> set[str | _T]:
        try:
            rgt = set(other)
        except TypeError:
            return NotImplemented
        ret: set[str | _T] = self - rgt  # type: ignore[assignment]
        ret |= rgt - self
        return ret

    __rxor__ = __xor__

    @_locked_md_pair
    def isdisjoint(self, other: Iterable[object]) -> bool:
        for key in other:
            if not isinstance(key, str):
                continue
            if key in self._md:
                return False
        return True


class _CSMixin:
    _ci: ClassVar[bool] = False

    def _key(self, key: str) -> str:
        return key

    def _identity(self, key: str) -> str:
        if type(key) is str:
            return key
        if isinstance(key, str):
            return str.__str__(key)
        raise TypeError("MultiDict keys should be either str or subclasses of str")


class _CIMixin:
    _ci: ClassVar[bool] = True

    def _key(self, key: str) -> str:
        if type(key) is str:
            return istr(key)
        if type(key) is istr:
            return key
        # istr(key) would call a subclass's own __str__, which may spell a
        # different string than the key
        return istr(str.__str__(key))

    def _identity(self, key: str) -> str:
        if isinstance(key, istr):
            ret = key.__istr_identity__
            if ret is None:
                ret = key.lower()
                key.__istr_identity__ = ret
            return ret
        if isinstance(key, str):
            # never a subclass's own lower()
            return str.lower(key)
        else:
            raise TypeError("MultiDict keys should be either str or subclasses of str")


def estimate_log2_keysize(n: int) -> int:
    # 7 == HT_MINSIZE - 1
    return (((n * 3 + 1) // 2) | 7).bit_length()


@dataclass
class _Entry(Generic[_V]):
    hash: int
    identity: str
    key: str
    value: _V


@dataclass
class _HtKeys(Generic[_V]):
    LOG_MINSIZE: ClassVar[int] = 3
    MINSIZE: ClassVar[int] = 8
    PREALLOCATED_INDICES: ClassVar[dict[int, array]] = {  # type: ignore[type-arg]
        log2_size: array(
            "b" if log2_size < 8 else "h", (-1 for i in range(1 << log2_size))
        )
        for log2_size in range(3, 10)
    }

    log2_size: int
    usable: int

    indices: array  # type: ignore[type-arg] # TODO(PY312): array[int]
    entries: list[_Entry[_V] | None]
    # first slot probed with perturb == 0 -> last slot used after it,
    # created on the first long probe
    resume_slots: dict[int, int] | None = None
    # set once an insert finds an equal hash on its probe chain, so two
    # entries may share an identity; never cleared, only carried
    maybe_dups: bool = False

    @functools.cached_property
    def nslots(self) -> int:
        return 1 << self.log2_size

    @functools.cached_property
    def mask(self) -> int:
        return self.nslots - 1

    if sys.implementation.name != "pypy":

        def __sizeof__(self) -> int:
            return (
                object.__sizeof__(self)
                + sys.getsizeof(self.indices)
                + sys.getsizeof(self.entries)
                + (0 if self.resume_slots is None else sys.getsizeof(self.resume_slots))
            )

    @classmethod
    def new(cls, log2_size: int, entries: list[_Entry[_V] | None]) -> Self:
        size = 1 << log2_size
        usable = (size << 1) // 3
        if log2_size < 10:
            indices = cls.PREALLOCATED_INDICES[log2_size].__copy__()
        elif log2_size < 16:
            indices = array("h", (-1 for i in range(size)))
        elif log2_size < 32:
            indices = array("l", (-1 for i in range(size)))
        else:  # pragma: no cover  # don't test huge multidicts
            indices = array("q", (-1 for i in range(size)))
        ret = cls(
            log2_size=log2_size,
            usable=usable,
            indices=indices,
            entries=entries,
        )
        return ret

    def clone(self) -> "_HtKeys[_V]":
        entries = [
            _Entry(e.hash, e.identity, e.key, e.value) if e is not None else None
            for e in self.entries
        ]

        return _HtKeys(
            log2_size=self.log2_size,
            usable=self.usable,
            indices=self.indices.__copy__(),
            entries=entries,
            maybe_dups=self.maybe_dups,
        )

    def build_indices(self) -> None:
        mask = self.mask
        indices = self.indices
        for idx, e in enumerate(self.entries):
            assert e is not None
            hash_ = e.hash
            i = hash_ & mask
            perturb = hash_
            while indices[i] != -1:
                perturb >>= 5
                i = mask & (i * 5 + perturb + 1)
                if not perturb:
                    i = self._find_empty_slot_resume(i)
                    break
            indices[i] = idx

    def find_empty_slot(self, hash_: int, absent: bool = False) -> int:
        # `absent`: the key was just looked up and is missing
        mask = self.mask
        indices = self.indices
        i = hash_ & mask
        perturb = hash_
        ix = indices[i]
        if ix != -1 and not absent and not self.maybe_dups:
            return self._find_empty_slot_noting_dups(hash_)
        while ix != -1:
            perturb >>= 5
            i = (i * 5 + perturb + 1) & mask
            if not perturb:
                return self._find_empty_slot_resume(i)
            ix = indices[i]
        return i

    def _find_empty_slot_noting_dups(self, hash_: int) -> int:
        # Sets maybe_dups on passing an entry of the same hash, possibly
        # marked by an update() in flight: an earlier entry of the new key's
        # identity would be there.  A probe long enough for the resume slots
        # sets it without looking.
        mask = self.mask
        indices = self.indices
        entries = self.entries
        i = hash_ & mask
        perturb = hash_
        ix = indices[i]
        while ix != -1:
            if ix >= 0 and entries[ix].hash & ~HASH_MARK == hash_:
                self.maybe_dups = True
                return self.find_empty_slot(hash_)
            perturb >>= 5
            i = (i * 5 + perturb + 1) & mask
            if not perturb:
                self.maybe_dups = True
                return self._find_empty_slot_resume(i)
            ix = indices[i]
        return i

    def _find_empty_slot_resume(self, start: int) -> int:
        mask = self.mask
        indices = self.indices
        resume_slots = self.resume_slots
        resume = None if resume_slots is None else resume_slots.get(start)
        # the resume slot is used, start after it
        i = start if resume is None else (resume * 5 + 1) & mask
        steps = 0
        while indices[i] != -1:
            i = (i * 5 + 1) & mask
            steps += 1
        if resume_slots is None:
            if (
                steps < _RESUME_SLOTS_MIN_STEPS
                or self.log2_size < _LOG_RESUME_SLOTS_MINSIZE
            ):
                return i
            resume_slots = self.resume_slots = {}
        resume_slots[start] = i
        return i

    def iter_hash(self, hash_: int) -> Iterator[tuple[int, int, _Entry[_V]]]:
        mask = self.mask
        indices = self.indices
        entries = self.entries
        i = hash_ & mask
        perturb = hash_
        ix = indices[i]
        while ix != -1:
            if ix != -2:
                e = entries[ix]
                if e.hash == hash_:
                    yield i, ix, e
            perturb >>= 5
            i = (i * 5 + perturb + 1) & mask
            ix = indices[i]

    def del_idx(self, hash_: int, idx: int) -> None:
        mask = self.mask
        indices = self.indices
        i = hash_ & mask
        perturb = hash_
        ix = indices[i]
        while ix != idx:
            perturb >>= 5
            i = (i * 5 + perturb + 1) & mask
            ix = indices[i]
        indices[i] = -2

    def iter_entries(self, reverse: bool = False) -> Iterator[_Entry[_V]]:
        entries = reversed(self.entries) if reverse else self.entries
        return filter(None, entries)

    def iter_first_entries(self, reverse: bool = False) -> Iterator[_Entry[_V]]:
        if not self.maybe_dups:
            yield from self.iter_entries(reverse)
        elif not reverse:
            seen = set()
            for e in self.iter_entries():
                if e.identity not in seen:
                    seen.add(e.identity)
                    yield e
        else:
            # Inserts take only empty slots and rebuilds reinsert in index
            # order, so the first entry of an identity on its probe chain is
            # its lowest index, the one getone() returns.
            entries = self.entries
            for idx in range(len(entries) - 1, -1, -1):
                entry = entries[idx]
                if entry is not None and idx == next(
                    ix
                    for _, ix, e2 in self.iter_hash(entry.hash)
                    if e2.identity == entry.identity
                ):
                    yield entry

    def restore_hash(self, hash_: int) -> None:
        mask = self.mask
        indices = self.indices
        entries = self.entries
        i = hash_ & mask
        perturb = hash_
        ix = indices[i]
        while ix != -1:
            if ix != -2:
                entry = entries[ix]
                if entry.hash & HASH_MARK:
                    entry.hash = hash_
            perturb >>= 5
            i = (i * 5 + perturb + 1) & mask
            ix = indices[i]


class MultiDict(_CSMixin, MutableMultiMapping[_V]):
    """Dictionary with the support for duplicate keys."""

    __slots__ = ("_keys", "_used", "_version", "_lock")

    _lock: threading.RLock

    # __new__ runs once per object, never on a later re-init, so the lock
    # identity is stable even across `d.__init__(other)`. The lock itself
    # is always created (not just under free-threading): update()/
    # extend()/merge()/clear()/popitem() need it on every build, since
    # their race isn't free-threading-specific -- see `_locked_always`.
    def __new__(cls, *args: object, **kwargs: object) -> Self:
        self = super().__new__(cls)
        self._lock = threading.RLock()
        return self

    @_locked_pair_always
    def __init__(self, arg: MDArg[_V] = None, /, **kwargs: _V):
        self._incr_version()
        if not kwargs:
            md = None
            if isinstance(arg, MultiDictProxy):
                md = arg._md
            elif isinstance(arg, MultiDict):
                md = arg
            if md is not None and md._ci is self._ci:
                self._from_md(md)
                return

        it = self._parse_args(arg, kwargs)
        log2_size = estimate_log2_keysize(cast(int, next(it)))
        if log2_size > 17:  # pragma: no cover
            # Don't overallocate really huge keys space in init
            log2_size = 17
        # Replacing the keys drops the old pairs, whose finalizers must
        # find the new state complete rather than have it written over.
        self._used = 0
        self._keys: _HtKeys[_V] = _HtKeys.new(log2_size, [])
        self._extend_items(cast(Iterator[_Entry[_V]], it))

    def _from_md(self, md: "MultiDict[_V]") -> None:
        # Copy everything as-is without compacting the new multidict,
        # otherwise it requires reindexing
        keys = md._keys.clone()
        self._used = md._used
        self._keys = keys

    @overload
    def getall(self, key: str) -> list[_V]: ...
    @overload
    def getall(self, key: str, default: _T) -> list[_V] | _T: ...
    @_locked
    def getall(self, key: str, default: _T | _SENTINEL = sentinel) -> list[_V] | _T:
        """Return a list of all values matching the key."""
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        res = []
        # Equal keys are first reached in insertion order; see
        # md_walk_with_hash() in _multilib/walk.h.
        last = -1
        for slot, idx, e in self._keys.iter_hash(hash_):
            if idx > last and e.identity == identity:
                res.append(e.value)
                last = idx
                if not self._keys.maybe_dups:
                    break  # the key's only entry

        if res:
            return res
        if default is not sentinel:
            return default
        raise KeyError(f"Key not found: {key!r}")

    @overload
    def getone(self, key: str) -> _V: ...
    @overload
    def getone(self, key: str, default: _T) -> _V | _T: ...
    @_locked
    def getone(self, key: str, default: _T | _SENTINEL = sentinel) -> _V | _T:
        """Get first value matching the key.

        Raises KeyError if the key is not found and no default is provided.
        """
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                return e.value
        if default is not sentinel:
            return default
        raise KeyError(f"Key not found: {key!r}")

    # Mapping interface #

    def __getitem__(self, key: str) -> _V:
        return self.getone(key)

    @overload
    def get(self, key: str, /) -> _V | None: ...
    @overload
    def get(self, key: str, /, default: _T) -> _V | _T: ...
    def get(self, key: str, default: _T | None = None) -> _V | _T | None:
        """Get first value matching the key.

        If the key is not found, returns the default (or None if no default is provided)
        """
        return self.getone(key, default)

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def __len__(self) -> int:
        return self._used

    def keys(self) -> KeysView[str]:
        """Return a new view of the dictionary's keys."""
        return _KeysView(self)

    def items(self) -> ItemsView[str, _V]:
        """Return a new view of the dictionary's items as ``(key, value)`` pairs."""
        return _ItemsView(self)

    def values(self) -> _ValuesView[_V]:
        """Return a new view of the dictionary's values."""
        return _ValuesView(self)

    @_locked_pair
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Mapping):
            return NotImplemented
        if isinstance(other, MultiDictProxy):
            return self == other._md
        if isinstance(other, MultiDict):
            lft = self._keys
            rht = other._keys
            if self._used != other._used:
                return False
            for e1, e2 in zip(lft.iter_entries(), rht.iter_entries()):
                if e1.identity != e2.identity or e1.value != e2.value:
                    return False
            return True
        if self._used != len(other):
            return False
        for k, v in self.items():
            nv = other.get(k, sentinel)
            if v != nv:
                return False
        return True

    @_locked
    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                return True
        return False

    @reprlib.recursive_repr()
    @_locked
    def __repr__(self) -> str:
        body = ", ".join(f"{e.key!r}: {e.value!r}" for e in self._keys.iter_entries())
        return f"<{self.__class__.__name__}({body})>"

    if sys.implementation.name != "pypy":

        def __sizeof__(self) -> int:
            return object.__sizeof__(self) + sys.getsizeof(self._keys)

    def __reduce__(self) -> tuple[type[Self], tuple[list[tuple[str, _V]]]]:
        return (self.__class__, (list(self.items()),))

    @_locked
    def to_dict(self) -> dict[str, list[_V]]:
        """Return a dict with lists of all values for each key."""
        result: dict[str, list[_V]] = {}
        # Keyed by identity so a case-insensitive multidict groups every
        # spelling of a key together, and holding the list itself rather than
        # the first key so the value append needs no second lookup.
        seen: dict[str, list[_V]] = {}
        version = self._version
        for e in self._keys.iter_entries():
            values = seen.get(e.identity)
            if values is None:
                values = seen[e.identity] = [e.value]
                result[self._key(e.key)] = values
            else:
                values.append(e.value)
            if self._version != version:
                # Building and hashing a key both run a str subclass's own
                # code, which must not mutate what is being converted.
                raise RuntimeError("Dictionary changed during iteration")
        return result

    @_locked_always
    def add(self, key: str, value: _V) -> None:
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        self._add_with_hash(_Entry(hash_, identity, key, value))
        self._incr_version()

    def copy(self) -> Self:
        """Return a copy of itself."""
        cls = self.__class__
        return cls(self)

    __copy__ = copy

    @_locked_pair_always
    def extend(self, arg: MDArg[_V] = None, /, **kwargs: _V) -> None:
        """Extend current MultiDict with more values.

        This method must be used instead of update.
        """
        it = self._parse_args(arg, kwargs)
        self._reserve(cast(int, next(it)))
        self._extend_items(cast(Iterator[_Entry[_V]], it))

    def _parse_args(
        self,
        arg: MDArg[_V],
        kwargs: Mapping[str, _V],
    ) -> Iterator[int | _Entry[_V]]:
        identity_func = self._identity
        if isinstance(arg, MultiDictProxy):
            if arg._md is self:
                arg = [(e.key, e.value) for e in self._keys.iter_entries()]
        elif arg is self:
            arg = [(e.key, e.value) for e in self._keys.iter_entries()]
        if arg:
            if isinstance(arg, MultiDictProxy):
                arg = arg._md
            if isinstance(arg, MultiDict):
                yield len(arg) + len(kwargs)
                if self._ci is not arg._ci:
                    key_func = arg._key
                    for e in arg._keys.iter_entries():
                        key = key_func(e.key)
                        if key is not e.key:
                            # a fresh istr keeps the source's identity
                            key.__istr_identity__ = e.identity  # type: ignore[attr-defined]
                        identity = identity_func(key)
                        yield _Entry(hash(identity) & MAXSIZE, identity, key, e.value)
                else:
                    for e in arg._keys.iter_entries():
                        yield _Entry(e.hash, e.identity, e.key, e.value)
                if kwargs:
                    for key, value in kwargs.items():
                        identity = identity_func(key)
                        yield _Entry(hash(identity) & MAXSIZE, identity, key, value)
            else:
                if hasattr(arg, "keys"):
                    arg = cast(SupportsKeys[_V], arg)
                    arg = [(k, arg[k]) for k in arg.keys()]
                if kwargs:
                    arg = list(arg)
                    arg.extend(list(kwargs.items()))
                try:
                    yield len(arg)  # type: ignore[arg-type]
                except TypeError:
                    yield 0
                for pos, item in enumerate(arg):
                    if not len(item) == 2:
                        raise ValueError(
                            f"multidict update sequence element #{pos} "
                            f"has length {len(item)}; 2 is required"
                        )
                    try:
                        key = item[0]
                    except Exception as exc:
                        raise ValueError(
                            f"multidict update sequence element #{pos}'s "
                            f"key could not be fetched"
                        ) from exc
                    try:
                        value = item[1]
                    except Exception as exc:
                        raise ValueError(
                            f"multidict update sequence element #{pos}'s "
                            f"value could not be fetched"
                        ) from exc
                    identity = identity_func(key)
                    yield _Entry(hash(identity) & MAXSIZE, identity, key, value)
        else:
            yield len(kwargs)
            for key, value in kwargs.items():
                identity = identity_func(key)
                yield _Entry(hash(identity) & MAXSIZE, identity, key, value)

    def _extend_items(self, items: Iterable[_Entry[_V]]) -> None:
        for e in items:
            self._add_with_hash(e)
        self._incr_version()

    @_locked_always
    def clear(self) -> None:
        """Remove all items from MultiDict."""
        self._used = 0
        self._keys = _HtKeys.new(_HtKeys.LOG_MINSIZE, [])
        self._incr_version()

    # Mapping interface #

    @_locked_always
    def __setitem__(self, key: str, value: _V) -> None:
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        found = False
        # See __delitem__()
        removed: list[object] = []

        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                if not found:
                    removed.append((e.key, e.value))
                    e.key = key
                    e.value = value
                    e.hash = hash_ | HASH_MARK
                    found = True
                    self._incr_version()
                elif not (e.hash & HASH_MARK):  # pragma: no branch
                    self._del_at(slot, idx)
                    removed.append(e)
                if not self._keys.maybe_dups:
                    break  # the key's only entry

        if not found:
            self._add_with_hash(_Entry(hash_, identity, key, value), absent=True)
        else:
            self._keys.restore_hash(hash_)

    @_locked_always
    def __delitem__(self, key: str) -> None:
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        # Holds the removed pairs until every match is gone: their
        # finalizers must not run, and add a match, mid-scan.
        removed = []
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                self._del_at(slot, idx)
                removed.append(e)
                if not self._keys.maybe_dups:
                    break  # the key's only entry
        if not removed:
            raise KeyError(key)
        else:
            self._incr_version()

    @overload
    def setdefault(
        self: "MultiDict[_T | None]", key: str, default: None = None
    ) -> _T | None: ...
    @overload
    def setdefault(self, key: str, default: _V) -> _V: ...
    @_locked_always  # type: ignore[misc]
    def setdefault(self, key: str, default: _V | None = None) -> _V | None:
        """Return value for key, set value to default if key is not present."""
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                return e.value
        self._add_with_hash(
            _Entry(hash_, identity, key, default),  # type: ignore[arg-type]
            absent=True,
        )
        self._incr_version()
        return default

    @overload
    def popone(self, key: str) -> _V: ...
    @overload
    def popone(self, key: str, default: _T) -> _V | _T: ...
    @_locked_always
    def popone(self, key: str, default: _T | _SENTINEL = sentinel) -> _V | _T:
        """Remove the first occurrence of key and return the corresponding value.

        If key is not found, default is returned if given, otherwise
        KeyError is raised.

        """
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                value = e.value
                self._del_at(slot, idx)
                self._incr_version()
                return value
        if default is sentinel:
            raise KeyError(key)
        else:
            return default

    # Type checking will inherit signature for pop() if we don't confuse it here.
    if not TYPE_CHECKING:
        pop = popone

    @overload
    def popall(self, key: str) -> list[_V]: ...
    @overload
    def popall(self, key: str, default: _T) -> list[_V] | _T: ...
    @_locked_always
    def popall(self, key: str, default: _T | _SENTINEL = sentinel) -> list[_V] | _T:
        """Remove all occurrences of key and return the list of corresponding
        values.

        If key is not found, default is returned if given, otherwise
        KeyError is raised.

        """
        identity = self._identity(key)
        hash_ = hash(identity) & MAXSIZE
        # See __delitem__()
        removed = []
        for slot, idx, e in self._keys.iter_hash(hash_):
            if e.identity == identity:  # pragma: no branch
                removed.append(e)
                self._del_at(slot, idx)
                self._incr_version()
                if not self._keys.maybe_dups:
                    break  # the key's only entry

        if not removed:
            if default is sentinel:
                raise KeyError(key)
            else:
                return default
        else:
            return [e.value for e in removed]

    @_locked_always
    def popitem(self) -> tuple[str, _V]:
        """Remove and return an arbitrary (key, value) pair."""
        if self._used <= 0:
            raise KeyError("empty multidict")

        entries = self._keys.entries
        pos = len(entries) - 1
        entry = entries[pos]
        while entry is None:
            pos -= 1
            entry = entries[pos]

        # Clear the indices slot before truncating entries, so a
        # concurrent unlocked read never sees an index pointing past
        # the end of the (now shorter) entries list.
        self._keys.del_idx(entry.hash, pos)
        del entries[pos:]
        # Not held past here: the pop can run a finalizer that replaces the
        # table, whose entries then go at once, as they do in C.
        del entries
        self._used -= 1
        self._incr_version()

        # istr() runs a str subclass's __str__, which may mutate self.
        return self._key(entry.key), entry.value

    @_locked_pair_always
    def update(self, arg: MDArg[_V] = None, /, **kwargs: _V) -> None:
        """Update the dictionary, overwriting existing keys."""
        it = self._parse_args(arg, kwargs)
        reserve = self._reserve_batch(cast(int, next(it)))
        # The entries this call wrote and those it doomed, by id(): kept
        # out of the table, they survive whatever runs between items. They
        # and `replaced` also hold the dropped pairs until the call ends.
        updated: dict[int, _Entry[_V]] = {}
        deleted: dict[int, tuple[_Entry[_V], _V]] = {}
        replaced: list[tuple[str, _V]] = []
        try:
            self._update_items(
                cast(Iterator[_Entry[_V]], it), updated, deleted, replaced, reserve
            )
        finally:
            self._post_update(deleted)

    def _update_items(
        self,
        items: Iterator[_Entry[_V]],
        updated: dict[int, _Entry[_V]],
        deleted: dict[int, tuple[_Entry[_V], _V]],
        replaced: list[tuple[str, _V]],
        reserve: int,
    ) -> None:
        for entry in items:
            found = False
            identity = entry.identity
            for slot, idx, e in self._keys.iter_hash(entry.hash):
                eid = id(e)
                if e.identity != identity or eid in updated:
                    continue
                if not found:
                    found = True
                    updated[eid] = e
                    if deleted:
                        # one an earlier item doomed keeps its position
                        deleted.pop(eid, None)
                    replaced.append((e.key, e.value))
                    e.key = entry.key
                    e.value = entry.value
                elif eid not in deleted:
                    # with what it holds now: a write since is kept
                    deleted[eid] = (e, e.value)
            if not found:
                if reserve:
                    self._reserve(reserve)
                    reserve = 0
                self._add_with_hash(entry)
                updated[id(entry)] = entry

    def _post_update(self, deleted: dict[int, tuple[_Entry[_V], _V]]) -> None:
        if deleted:
            keys = self._keys
            indices = keys.indices
            entries = keys.entries
            for slot in range(keys.nslots):
                idx = indices[slot]
                if idx < 0:
                    continue
                doomed = deleted.get(id(entries[idx]))
                if doomed is not None:
                    e, value = doomed
                    if e.value is value:
                        entries[idx] = None
                        indices[slot] = -2
                        self._used -= 1
        self._incr_version()

    @_locked_pair_always
    def merge(self, arg: MDArg[_V] = None, /, **kwargs: _V) -> None:
        """Merge into the dictionary, adding non-existing keys."""
        it = self._parse_args(arg, kwargs)
        reserve = self._reserve_batch(cast(int, next(it)))
        try:
            self._merge_items(cast(Iterator[_Entry[_V]], it), reserve)
        finally:
            self._incr_version()

    def _merge_items(self, items: Iterator[_Entry[_V]], reserve: int) -> None:
        # See update()
        added: dict[int, _Entry[_V]] = {}
        for entry in items:
            identity = entry.identity
            for slot, idx, e in self._keys.iter_hash(entry.hash):
                if e.identity == identity and id(e) not in added:
                    break
            else:
                if reserve:
                    self._reserve(reserve)
                    reserve = 0
                self._add_with_hash(entry)
                added[id(entry)] = entry

    if _FREE_THREADED:
        # `_version` is shared by every instance, so it needs its own lock.
        def _incr_version(self) -> None:
            with _VERSION_LOCK:
                v = next(_version)
            self._version = v

    else:
        # One C call, so the GIL cannot switch threads in the middle of it.
        def _incr_version(self) -> None:
            self._version = next(_version)

    def _reserve(self, extra: int) -> None:
        if self._keys.usable < extra:
            self._resize(estimate_log2_keysize(self._used + extra))

    def _reserve_batch(self, extra: int) -> int:
        # update() and merge() often find their keys there already: see
        # md_reserve_batch(). Returns the room their first add makes.
        keys = self._keys
        n = len(keys.entries)
        if n != self._used or n + keys.usable < extra:
            self._reserve(extra)
        return extra

    def _resize(self, log2_newsize: int) -> None:
        oldkeys = self._keys
        newentries = self._used

        if len(oldkeys.entries) == newentries:
            entries = oldkeys.entries
        else:
            entries = [e for e in oldkeys.entries if e is not None]
        newkeys: _HtKeys[_V] = _HtKeys.new(log2_newsize, entries)
        newkeys.maybe_dups = oldkeys.maybe_dups
        newkeys.usable -= newentries
        newkeys.build_indices()
        self._keys = newkeys

    def _add_with_hash(self, entry: _Entry[_V], absent: bool = False) -> None:
        if self._keys.usable <= 0:
            self._resize((self._used * 3 | _HtKeys.MINSIZE - 1).bit_length())
        keys = self._keys
        slot = keys.find_empty_slot(entry.hash, absent)
        keys.entries.append(entry)
        keys.indices[slot] = len(keys.entries) - 1
        self._incr_version()
        self._used += 1
        keys.usable -= 1

    def _del_at(self, slot: int, idx: int) -> None:
        self._keys.entries[idx] = None
        self._keys.indices[slot] = -2
        self._used -= 1


class CIMultiDict(_CIMixin, MultiDict[_V]):
    """Dictionary with the support for duplicate case-insensitive keys."""


class MultiDictProxy(_CSMixin, MultiMapping[_V]):
    """Read-only proxy for MultiDict instance."""

    __slots__ = ("_md",)

    _md: MultiDict[_V]

    def __init__(self, arg: "MultiDict[_V] | MultiDictProxy[_V]"):
        if not isinstance(arg, (MultiDict, MultiDictProxy)):
            raise TypeError(
                f"ctor requires MultiDict or MultiDictProxy instance, not {type(arg)}"
            )
        if isinstance(arg, MultiDictProxy):
            self._md = arg._md
        else:
            self._md = arg

    def __reduce__(self) -> NoReturn:
        raise TypeError(f"can't pickle {self.__class__.__name__} objects")

    @overload
    def getall(self, key: str) -> list[_V]: ...
    @overload
    def getall(self, key: str, default: _T) -> list[_V] | _T: ...
    def getall(self, key: str, default: _T | _SENTINEL = sentinel) -> list[_V] | _T:
        """Return a list of all values matching the key."""
        if default is not sentinel:
            return self._md.getall(key, default)
        else:
            return self._md.getall(key)

    @overload
    def getone(self, key: str) -> _V: ...
    @overload
    def getone(self, key: str, default: _T) -> _V | _T: ...
    def getone(self, key: str, default: _T | _SENTINEL = sentinel) -> _V | _T:
        """Get first value matching the key.

        Raises KeyError if the key is not found and no default is provided.
        """
        if default is not sentinel:
            return self._md.getone(key, default)
        else:
            return self._md.getone(key)

    # Mapping interface #

    def __getitem__(self, key: str) -> _V:
        return self.getone(key)

    @overload
    def get(self, key: str, /) -> _V | None: ...
    @overload
    def get(self, key: str, /, default: _T) -> _V | _T: ...
    def get(self, key: str, default: _T | None = None) -> _V | _T | None:
        """Get first value matching the key.

        If the key is not found, returns the default (or None if no default is provided)
        """
        return self._md.getone(key, default)

    def __iter__(self) -> Iterator[str]:
        return iter(self._md.keys())

    def __len__(self) -> int:
        return len(self._md)

    def keys(self) -> KeysView[str]:
        """Return a new view of the dictionary's keys."""
        return self._md.keys()

    def items(self) -> ItemsView[str, _V]:
        """Return a new view of the dictionary's items as ``(key, value)`` pairs."""
        return self._md.items()

    def values(self) -> _ValuesView[_V]:
        """Return a new view of the dictionary's values."""
        return self._md.values()

    def __eq__(self, other: object) -> bool:
        return self._md == other

    def __contains__(self, key: object) -> bool:
        return key in self._md

    @reprlib.recursive_repr()
    def __repr__(self) -> str:
        body = ", ".join(f"{k!r}: {v!r}" for k, v in self.items())
        return f"<{self.__class__.__name__}({body})>"

    def to_dict(self) -> dict[str, list[_V]]:
        """Return a dict with lists of all values for each key."""
        return self._md.to_dict()

    def copy(self) -> MultiDict[_V]:
        """Return a copy of itself."""
        return MultiDict(self._md)


class CIMultiDictProxy(_CIMixin, MultiDictProxy[_V]):
    """Read-only proxy for CIMultiDict instance."""

    def __init__(self, arg: MultiDict[_V] | MultiDictProxy[_V]):
        if not isinstance(arg, (CIMultiDict, CIMultiDictProxy)):
            raise TypeError(
                "ctor requires CIMultiDict or CIMultiDictProxy instance"
                f", not {type(arg)}"
            )

        super().__init__(arg)

    def copy(self) -> CIMultiDict[_V]:
        """Return a copy of itself."""
        return CIMultiDict(self._md)


def getversion(md: MultiDict[object] | MultiDictProxy[object]) -> int:
    if isinstance(md, MultiDictProxy):
        md = md._md
    elif not isinstance(md, MultiDict):
        raise TypeError("Parameter should be multidict or proxy")
    return md._version
