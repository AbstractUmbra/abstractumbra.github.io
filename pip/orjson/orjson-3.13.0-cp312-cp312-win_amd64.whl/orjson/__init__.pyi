# SPDX-License-Identifier: (Apache-2.0 OR MIT)
# Copyright ijl (2019-2026), Eric Jolibois (2022), Anders Kaseorg (2020)

import json
from collections.abc import Callable
from typing import Any

__version__: str

def dumps(
    __obj: Any,
    default: Callable[[Any], Any] | None = ...,
    option: int | None = ...,
) -> bytes: ...
def loads(__obj: bytes | bytearray | memoryview | str) -> Any: ...

class JSONDecodeError(json.JSONDecodeError): ...
class JSONEncodeError(TypeError): ...

class Fragment(tuple):
    contents: bytes | str

OPT_APPEND_NEWLINE: int
OPT_INDENT_2: int
OPT_NAIVE_UTC: int
OPT_NON_STR_KEYS: int
OPT_OMIT_MICROSECONDS: int
OPT_PASSTHROUGH_DATACLASS: int
OPT_PASSTHROUGH_DATETIME: int
OPT_PASSTHROUGH_SUBCLASS: int
OPT_SERIALIZE_DATACLASS: int
OPT_SERIALIZE_NUMPY: int
OPT_SERIALIZE_UUID: int
OPT_SORT_KEYS: int
OPT_STRICT_INTEGER: int
OPT_UTC_Z: int
